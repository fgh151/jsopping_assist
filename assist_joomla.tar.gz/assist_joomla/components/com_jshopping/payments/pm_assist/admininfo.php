<!--<p>RESULT URL : http://ИМЯ-ВАШЕГО-САЙТА/index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_assist</p>-->
<p>SUCCESS URL : http://ИМЯ-ВАШЕГО-САЙТА/index.php?option=com_jshopping&controller=checkout&task=step7&act=success&js_paymentclass=pm_assist</p>
<p>FAIL URL : http://ИМЯ-ВАШЕГО-САЙТА/index.php?option=com_jshopping&controller=checkout&task=step7&act=cancel&js_paymentclass=pm_assist</p>
