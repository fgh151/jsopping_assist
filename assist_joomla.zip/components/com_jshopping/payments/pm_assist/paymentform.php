<script type="text/javascript">
function check_pm_assist(){
    $_('payment_form').submit();
}
</script>

